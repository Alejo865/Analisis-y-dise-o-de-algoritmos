import inspect

from flask import Blueprint, render_template, redirect, request, url_for, session

from repositories.exercise_repository import ExerciseRepository
from services.algoritmos import catalogo
from services.algoritmos.backtracking import conflicto_reina, resolver_reinas
from services.algoritmos.merge_sort import CRITERIOS, ordenar_ejercicios
from services.algoritmos.programacion_dinamica import (
    N_MAXIMO,
    comparar_escaleras,
    escaleras_memoizado,
    validar_n,
)

practica_bp = Blueprint('practica', __name__)

@practica_bp.route('/practica')
def mostrar_practica():
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    return render_template('practica.html')


@practica_bp.route('/practica/ejercicios')
def ejercicios_ordenados():
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    criterio = request.args.get('orden', 'dificultad')
    if criterio not in CRITERIOS:
        criterio = 'dificultad'

    ejercicios = [
        {**ejercicio, 'orden_original': posicion}
        for posicion, ejercicio in enumerate(ExerciseRepository().find_all(), start=1)
    ]
    resultado = ordenar_ejercicios(ejercicios, criterio)

    return render_template(
        'laboratorio/ejercicios.html',
        ejercicios=resultado.elementos,
        resultado=resultado,
        criterio=criterio,
        criterios=[(clave, nombre) for clave, (nombre, _) in CRITERIOS.items()],
    )


@practica_bp.route('/practica/laboratorio')
def laboratorio():
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    return render_template(
        'laboratorio/indice.html',
        interactivos=catalogo.INTERACTIVOS,
        educativos=catalogo.EDUCATIVOS,
    )


@practica_bp.route('/practica/laboratorio/programacion-dinamica')
def laboratorio_programacion_dinamica():
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    error = None
    estado = 200
    try:
        n = validar_n(request.args.get('n', '8'))
    except ValueError as exc:
        error, n, estado = str(exc), 8, 400

    return render_template(
        'laboratorio/programacion_dinamica.html',
        r=comparar_escaleras(n),
        n_maximo=N_MAXIMO,
        error=error,
        codigo=inspect.getsource(escaleras_memoizado),
    ), estado


@practica_bp.route('/practica/laboratorio/backtracking')
def laboratorio_backtracking():
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    error = None
    estado = 200
    try:
        numero = int(request.args.get('solucion', '1'))
        if numero not in (1, 2):  # el tablero de 4 x 4 tiene exactamente 2 soluciones
            raise ValueError
    except ValueError:
        error, numero, estado = 'Elige la solución 1 o la solución 2.', 1, 400

    return render_template(
        'laboratorio/backtracking.html',
        r=resolver_reinas(4, numero),
        error=error,
        codigo=inspect.getsource(conflicto_reina) + '\n\n' + inspect.getsource(resolver_reinas),
    ), estado
