"""Catálogo del Laboratorio de algoritmos.

Cada entrada describe una actividad y la ruta (endpoint de Flask) que la
muestra. Se añade una entrada solo cuando la actividad existe de verdad.
"""

INTERACTIVOS = [
    {
        "slug": "merge-sort",
        "nombre": "Merge Sort",
        "endpoint": "practica.ejercicios_ordenados",
        "descripcion": "Ordena los ejercicios de Practicar por dificultad o por posición.",
        "concepto": "Divide y vencerás · recursividad · O(n log n)",
    },
    {
        "slug": "programacion-dinamica",
        "nombre": "Programación dinámica",
        "endpoint": "practica.laboratorio_programacion_dinamica",
        "descripcion": "Cuenta de cuántas formas se sube una escalera y compara recursión con memoización.",
        "concepto": "Subproblemas superpuestos · memoización · optimización",
    },
    {
        "slug": "backtracking",
        "nombre": "Backtracking: las 4 reinas",
        "endpoint": "practica.laboratorio_backtracking",
        "descripcion": "Observa cómo el algoritmo prueba posiciones, descarta conflictos y retrocede en un tablero de 4 × 4.",
        "concepto": "Retroceso · poda · restricciones · caso base",
    },
]

EDUCATIVOS = []
