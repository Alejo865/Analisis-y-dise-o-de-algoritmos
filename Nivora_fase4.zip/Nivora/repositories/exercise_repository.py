from database.database import DatabaseConnection


class ExerciseRepository:
    def __init__(self, database=None):
        self.database = database or DatabaseConnection()

    def find_all(self):
        """Devuelve todos los ejercicios con el nombre de su unidad."""
        connection = self.database.connect()
        try:
            rows = connection.execute(
                """
                SELECT e.id_ejercicio, e.titulo, e.descripcion, e.dificultad,
                       e.id_unidad, u.nombre AS unidad
                FROM EJERCICIO e
                JOIN UNIDAD u ON u.id_unidad = e.id_unidad
                ORDER BY e.id_ejercicio
                """
            ).fetchall()
            return [dict(row) for row in rows]
        finally:
            connection.close()
